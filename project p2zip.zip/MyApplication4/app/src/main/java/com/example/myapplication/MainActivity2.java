package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;

class MainActivity2 extends AppCompatActivity {

    Button btnBookTour, btnViewTours, btnExplore;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnBookTour = findViewById(R.id.btnBookTour);
        btnViewTours = findViewById(R.id.btnViewTours);
        btnExplore = findViewById(R.id.btnExplore);

        btnBookTour.setOnClickListener(v ->
                        Toast.makeText(this, "Book Tour Clicked", Toast.LENGTH_SHORT).show()
                // startActivity(new Intent(this, BookTourActivity.class));
        );

        btnViewTours.setOnClickListener(v ->
                        Toast.makeText(this, "View Tours Clicked", Toast.LENGTH_SHORT).show()
                // startActivity(new Intent(this, ViewToursActivity.class));
        );

        btnExplore.setOnClickListener(v ->
                        Toast.makeText(this, "Explore Clicked", Toast.LENGTH_SHORT).show()
                // startActivity(new Intent(this, ExploreActivity.class));
        );
    }
}
