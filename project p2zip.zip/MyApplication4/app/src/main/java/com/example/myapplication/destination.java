package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

class acitivity_destination extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Make sure your layout file is named activity_main.xml

        setupDestination(R.id.bali_layout,
                R.drawable.bali_header,
                "Bali - 10 Tours - 5 Days - 125 KM",
                "Fly to Bali - $1000.00",
                "Kanvaz Village Resort - $1000.00",
                "Tour of Kanvaz Resort - $250.00");

        setupDestination(R.id.australia_layout,
                R.drawable.australia_header,
                "Australia - 8 Tours - 7 Days - 400 KM",
                "Fly to Australia - $1200.00",
                "Sydney Harbour Hotel - $1100.00",
                "City Tour - $300.00");

        setupDestination(R.id.dubai_layout,
                R.drawable.dubai_header,
                "Dubai - 12 Tours - 4 Days - 150 KM",
                "Fly to Dubai - $900.00",
                "Atlantis The Palm - $950.00",
                "Desert Safari - $200.00");

        setupDestination(R.id.newyork_layout,
                R.drawable.newyork_header,
                "New York - 9 Tours - 6 Days - 300 KM",
                "Fly to New York - $1300.00",
                "Times Square Hotel - $1200.00",
                "Statue of Liberty Tour - $280.00");

        setupDestination(R.id.turkey_layout,
                R.drawable.turkey_header,
                "Turkey - 7 Tours - 5 Days - 220 KM",
                "Fly to Turkey - $950.00",
                "Istanbul Palace Hotel - $900.00",
                "Hagia Sophia Tour - $230.00");

        setupDestination(R.id.egypt_layout,
                R.drawable.egypt_header,
                "Egypt - 6 Tours - 6 Days - 180 KM",
                "Fly to Egypt - $1000.00",
                "Pyramids View Hotel - $850.00",
                "Pyramids Tour - $270.00");
    }

    private void setupDestination(int layoutId, int imageRes, String title, String flight, String hotel, String tour) {
        LinearLayout layout = findViewById(layoutId);
        ((ImageView) layout.findViewById(R.id.imageHeader)).setImageResource(imageRes);
        ((TextView) layout.findViewById(R.id.textTitle)).setText(title);
        ((TextView) layout.findViewById(R.id.textFlight)).setText(flight);
        ((TextView) layout.findViewById(R.id.textHotel)).setText(hotel);
        ((TextView) layout.findViewById(R.id.textTour)).setText(tour);

        Button bookButton = layout.findViewById(R.id.buttonBook);
        bookButton.setOnClickListener(view -> {
            // Handle booking click - can launch new activity or show a dialog
        });
    }
}
