package com.example.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView destinationName = findViewById(R.id.destination_name);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button confirmButton = findViewById(R.id.confirm_button);

        // Receive destination from Intent
        String destination = getIntent().getStringExtra("destination");
        if (destination != null) {
            destinationName.setText(destination);
        }

        confirmButton.setOnClickListener(v -> {
            Toast.makeText(this, "Booking confirmed for " + destinationName.getText(), Toast.LENGTH_SHORT).show();
            finish(); // Go back or proceed to another screen
        });
    }
}
