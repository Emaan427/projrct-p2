package com.example.myapplication;

public interface FirebaseAuth {
}
